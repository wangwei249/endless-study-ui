ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1202433.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': true,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 52565086, 52565097, 52565079, 52565104, 52565075, 52565074, 52565085, 52565105, 52565090, 52565106, 52565087, 52565103, 93153302 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
